<?php

/**
 * @file
 * Esperanto transliteration data for the PhpTransliteration class.
 */

$overrides['eo'] = [
  0x18 => 'Cx',
  0x19 => 'cx',
  0x11C => 'Gx',
  0x11D => 'gx',
  0x124 => 'Hx',
  0x125 => 'hx',
  0x134 => 'Jx',
  0x135 => 'jx',
  0x15C => 'Sx',
  0x15D => 'sx',
  0x16C => 'Ux',
  0x16D => 'ux',
];
